<?php

namespace App\Repository;

use App\Entity\ShipPlacement;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Persistence\ManagerRegistry;

/**
 * @method ShipPlacement|null find($id, $lockMode = null, $lockVersion = null)
 * @method ShipPlacement|null findOneBy(array $criteria, array $orderBy = null)
 * @method ShipPlacement[]    findAll()
 * @method ShipPlacement[]    findBy(array $criteria, array $orderBy = null, $limit = null, $offset = null)
 */
class ShipPlacementRepository extends ServiceEntityRepository
{
    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, ShipPlacement::class);
    }

    public function deleteAllShipPlacements(){
        $query = $this->createQueryBuilder('s')
            ->delete()
            ->getQuery()
            ->execute();
        return $query;
    }
}
