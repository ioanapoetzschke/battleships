<?php

namespace App\Repository;

use App\Entity\Location;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Persistence\ManagerRegistry;
use App\Entity\Position;
use App\Entity\Grid;



/**
 * @method Location|null find($id, $lockMode = null, $lockVersion = null)
 * @method Location|null findOneBy(array $criteria, array $orderBy = null)
 * @method Location[]    findAll()
 * @method Location[]    findBy(array $criteria, array $orderBy = null, $limit = null, $offset = null)
 */
class LocationRepository extends ServiceEntityRepository
{
    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, Location::class);
    }

    /**
     * @param Grid $grid
     * @param array $values
     * @param int $x
     * @param int $y
     * @return Location[] Returns an array of Location objects
     */
    public function findHorizontallyByPosition(Grid $grid, array $values, int $x, int $y)
    {
        return $this->createQueryBuilder('l')
            ->andWhere('l.grid_id = :grid_id')
            ->setParameter('grid_id', $grid->getId())
            ->andWhere('l.x IN (:values)')
            ->setParameter('values', $values)
            ->andWhere('l.y = :yVal')
            ->setParameter('yVal', $y)
            ->getQuery()
            ->getResult()
            ;
    }

    /**
     * @param Grid $grid
     * @param array $values
     * @param int $x
     * @param int $y
     * @return Location[] Returns an array of Location objects
     */
    public function findVerticallyByPosition(Grid $grid, array $values, int $x, int $y)
    {
        return $this->createQueryBuilder('l')
            ->andWhere('l.grid_id = :grid_id')
            ->setParameter('grid_id', $grid->getId())
            ->andWhere('l.y IN (:values)')
            ->setParameter('values', $values)
            ->andWhere('l.x = :xVal')
            ->setParameter('xVal', $x)
            ->getQuery()
            ->getResult()
            ;
    }

    /**
     * @param Grid $grid
     * @param int $x
     * @param int $y
     * @return mixed
     */
    public function getLocationByPosition(Grid $grid, int $x, int $y)
    {
        return $this->createQueryBuilder('l')
            ->andWhere('l.grid_id = :grid_id')
            ->setParameter('grid_id', $grid->getId())
            ->andWhere('l.y = :yVal')
            ->setParameter('yVal', $y)
            ->andWhere('l.x = :xVal')
            ->setParameter('xVal', $x)
            ->getQuery()
            ->getResult()
            ;
    }


    /**
     * @param Grid $grid
     * @return mixed
     */
    public function findShotLocationWithShipNotSunk(Grid $grid)
    {
        $result = $this->createQueryBuilder('l')
            ->join('l.ship_placement', 'sp')
            ->join('sp.ship', 's')
            ->andWhere('l.shot = true')
            ->andWhere('sp.hits < s.holes')
            ->andWhere('l.grid = :grid')
            ->setParameter('grid', $grid)
            ->setMaxResults(1)
            ->select('l.id, l.x, l.y')
            ->getQuery()
            ->execute();


        return $result;
    }

    /**
     * @param Grid $grid
     * @param Location $location
     * @return Location[] Returns an array of Location objects
     */
    public function findNearShotLocations(Grid $grid, Location $location)
    {
        $yValues = [];
        $xValues = [];

        if($location->getY() - 1 >= 1){
            $yValues[] = $location->getY() - 1;
        }
        if($location->getY() + 1 <= 8){
            $yValues[] = $location->getY() + 1;
        }

        if($location->getX() - 1 >= 1){
            $xValues[] = $location->getX() - 1;
        }
        if($location->getX() + 1 <= 8){
            $xValues[] = $location->getX() + 1;
        }

        return $this->createQueryBuilder('l')
            ->andWhere('l.grid_id = :grid_id')
            ->setParameter('grid_id', $grid->getId())
            ->andWhere('l.y IN (:yValues)')
            ->setParameter('yValues', $yValues)
            ->andWhere('l.x IN (:xValues)')
            ->setParameter('xValues', $xValues)
            ->andWhere('l.shot = true')
            ->getQuery()
            ->getResult()
            ;
    }

    public function deleteAllLocations()
    {
        $query = $this->createQueryBuilder('l')
            ->delete()
            ->getQuery()
            ->execute();
        return $query;
    }
}
