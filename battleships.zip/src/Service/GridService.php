<?php

namespace App\Service;

use App\Entity\Grid;
use App\Entity\Location;
use App\Entity\Ship;
use App\Entity\ShipPlacement;
use App\Repository\LocationRepository;
use Doctrine\ORM\EntityManagerInterface;
use App\Service\LocationService;

class GridService
{

    public static $MAX_TOTAL_SHOTS = 17;

    private $em;
    private $locationService;

    public function __construct(EntityManagerInterface $em, LocationService $locationService)
    {
        $this->em = $em;
        $this->locationService = $locationService;
    }

    /**
     * Initialise own grid
     * @return Grid
     */
    public function initialiseOwnGrid()
    {
        /**
         * @var $ownGrid Grid
         */
        $ownGrid = $this->em
            ->getRepository(Grid::class)
            ->findOneBy(['client_id' => 'own']);

        if(is_null($ownGrid)){
            //create own grid
            $ownGrid = new Grid();
            $ownGrid->setClientId('own');
        }

        $ownGrid->setTotalHits(0);
        $this->em->persist($ownGrid);

        $this->em->flush();

        // create locations with ships
        $this->locationService->generateLocationsForAllShips($ownGrid);

        return $ownGrid;
    }

    /**
     * Create party grid | Reset party grid if it exists
     * @param string $client_id
     * @return Grid
     */
    public function initialisePartyGrid(string $client_id)
    {
        /**
         * @var $partyGrid Grid
         */
        $partyGrid = $this->em
            ->getRepository(Grid::class)
            ->findOneBy(['client_id' => $client_id]);

        if(is_null($partyGrid)){
            //create own grid
            $partyGrid = new Grid();
            $partyGrid->setClientId($client_id);
        }

        $partyGrid->setTotalHits(0);
        $this->em->persist($partyGrid);
        $this->em->flush();

        return $partyGrid;

    }

    /**
     * @return Grid
     */
    public function getOwnGrid()
    {
        /**
         * @var $ownGrid Grid
         */
        $ownGrid = $this->em
            ->getRepository(Grid::class)
            ->findOneBy(['client_id' => 'own']);
        return $ownGrid;
    }

    /**
     * @return Grid|null
     */
    public function getPartyGrid()
    {
        /**
         * @var $partyGrid Grid
         */
        $partyGrid = $this->em
            ->getRepository(Grid::class)
            ->findOneBy(['client_id' => 'party_grid']);

        return $partyGrid;
    }
}