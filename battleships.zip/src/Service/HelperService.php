<?php

namespace App\Service;

use App\Entity\Grid;
use App\Entity\Location;
use App\Entity\Ship;
use App\Entity\ShipPlacement;
use App\Repository\LocationRepository;
use Doctrine\ORM\EntityManager;
use Doctrine\ORM\EntityManagerInterface;
use App\Service\LocationService;

class HelperService
{

    private static $LETTERS_MAP = [
        'A' => 1,
        'B' => 2,
        'C' => 3,
        'D' => 4,
        'E' => 5,
        'F' => 6,
        'G' => 7,
        'H' => 8
    ];

    private $em;

    public function __construct(EntityManager $em)
    {
        $this->em = $em;
    }

    /**
     * @param $number
     * @return string |null
     */
    public static function getLetterForNumber($number)
    {
        $letter = array_search($number, self::$LETTERS_MAP);

        if(isset($letter)){
            return $letter;
        } else {
            return '';
        }
    }

    /**
     * @param $letter
     * @return int |null
     */
    public static function getNumberForLetter($letter)
    {
        if(isset(self::$LETTERS_MAP[$letter])){
            return self::$LETTERS_MAP[$letter];
        }
        return null;
    }

    public static function convertStringToPositionArray(string $shot){
        $shotParts = [];
        $x = null;
        $y = null;
        $result = [];
        if(isset($shot) && strlen($shot) >= 3){
            $shotParts = explode('-', $shot);
        }
        if(count($shotParts) == 2){
            $y = self::getNumberForLetter($shotParts[0]);
            $x = (int)$shotParts[1];

            if(isset($x) && isset($y) && is_numeric($x) && is_numeric($y))
            {
                $result['x'] = $x;
                $result['y'] = $y;
            }
        }

        return $result;
    }

    public static function convertPositionArrayToString(array $position){
        $x = null;
        $y = null;
        $result = '';
        if(count($position) == 2 && is_numeric($position[0]) && is_numeric($position[1])){
            $y = self::getLetterForNumber($position[1]);
            if(isset($y)){
                $result = $y . '-' . $position[0];
            }
        }
        return $result;
    }

    /**
     * @return array
     */
    public static function generateRandomPosition(){

        // generate random position
        $x = rand(1, 8);
        $y = rand(1, 8);

        return ['x' => $x, 'y' => $y];
    }


    /**
     * Parse result from party request. e.g " A-6 : HIT CRUISER", "A-6: MISS"
     * @param string $value
     * @return array
     */
    public static function parseResult(string $value){

        $parts = null;
        $result = [];

        if(isset($value)){
            $parts = explode(':', $value);
            if(!empty($parts) && count($parts) == 2){
                $result['position'] = self::convertStringToPositionArray(trim($parts[0]));
                if( is_array($result['position']) &&
                    isset($result['position']['x']) &&
                    isset($result['position']['y'])){
                    // continue only if position could be parsed
                    $parts = trim($parts[1]) !== 'MISS' ? explode(' ',trim($parts[1])) : $parts = trim($parts[1]);
                    if(!empty($parts)){
                        switch (strtoupper($parts[0]))
                        {
                            case 'MISS':
                                $result['hit'] = false;
                                break;

                            case 'HIT':
                                $result['hit'] = true;
                                $result['ship_name'] = strtoupper($parts[1]);
                                break;
                                /*if(isset($parts[1])){
                                    // get ship by name
                                    $ship = $this->em->getRepository(Ship::class)
                                        ->findOneBy(['name' => strtoupper($parts[1])]);
                                    $result['ship'] = $ship;
                                }*/
                            default:
                                $result['hit'] = null;
                        }
                    }
                }
            }
        }
        return $result;
    }
}