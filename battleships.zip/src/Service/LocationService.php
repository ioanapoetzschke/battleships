<?php
/**
 * Created by PhpStorm.
 * User: ioana.poetzschke
 * Date: 16.05.2020
 * Time: 06:29
 */

namespace App\Service;

use App\Entity\Grid;
use App\Entity\Location;
use App\Entity\Position;
use App\Entity\Ship;
use App\Entity\ShipPlacement;
use App\Repository\LocationRepository;
use Doctrine\ORM\EntityManagerInterface;


class LocationService{

    private $em;

    public function __construct(EntityManagerInterface $em){
        $this->em = $em;
    }

    /**
     * @param Grid $grid
     */
    public function deleteAllLocationsByGridId(Grid $grid){

        foreach ($grid->getLocations() as $location){
            $location->setShipPlacement(null);
            $grid->removeLocation($location);
        }

        $this->em->flush();
    }

    /**
     * @param Grid $grid
     */
    public function generateLocationsForAllShips(Grid $grid){

        // get all ships ordered by holes
        $ships = $this->em
            ->getRepository(Ship::class)
            ->findBy([], ['holes' => 'DESC']);

        foreach ($ships as $ship){
            $this->generateLocationsForOneShip($grid, $ship);
        }
    }

    /**
     * @param Grid $grid
     * @param int $x
     * @param int $y
     * @return Location|null
     */
    public function getLocationByPosition(Grid $grid, int $x, int $y){

        return $this->em->getRepository(Location::class)
                    ->findOneBy(['grid_id' => $grid->getId(), 'x' => $x, 'y' => $y]);

    }

    /**
     * @param Grid $grid
     * @param Location $location
     * @return array
     */
    public function getNearLocation(Grid $grid, Location $location){

        $positions = [];
        $targetPosition = null;
        $existLocation = null;
        $direction= null;
        $foundLocation = null;

        if($location->getY() - 1 >= 1){
            $position = ['x' => $location->getX(), 'y' => $location->getY() - 1];
            $existLocation = $this->getLocationByPosition($grid, $position['x'], $position['y']);
            if(!($existLocation instanceof  Location)){
                $positions[] = $position;
            }
        }

        if($location->getY() + 1 <= 8){
            $position = ['x' => $location->getX(), 'y' => $location->getY() + 1];
            $existLocation = $this->getLocationByPosition($grid, $position['x'], $position['y']);
            if(!($existLocation instanceof  Location)){
                $positions[] = $position;
            }
        }

        if($location->getX() - 1 >= 1){
            $position = ['x' => $location->getX() - 1, 'y' => $location->getY()];
            $existLocation = $this->getLocationByPosition($grid, $position['x'], $position['y']);
            if(!($existLocation instanceof  Location)){
                $positions[] = $position;
            }
        }

        if($location->getX() + 1 <= 8){
            $position = ['x' => $location->getX() + 1, 'y' => $location->getY()];
            $existLocation = $this->getLocationByPosition($grid, $position['x'], $position['y']);
            if(!($existLocation instanceof  Location)){
                $positions[] = $position;
            }
        }

        if( $existLocation instanceof  Location && !is_null($existLocation->getShipPlacement())){
            // get near position of the next location that was shot and owns a ship that is not sunk
            return $this->getNearLocation($grid, $existLocation);
        } else {
            return $positions;
        }
    }

    /**
     * @param Grid $grid
     * @param Ship $ship
     */
    private function generateLocationsForOneShip(Grid $grid, Ship $ship){

        $locations = $this->findFreeLocations($grid, $ship);

        if(is_array($locations) && count($locations) == $ship->getHoles()){
            //TODO set ship placement only for locations of party grid
            $ship_placement = new ShipPlacement();
            $ship_placement->setShip($ship);
            $ship_placement->setGrid($grid);
            $ship_placement->setHits(0);
            foreach ($locations as $location){
                if($location instanceof  Location){
                    if(is_null($location->getShipPlacement())){
                        $location->setShipPlacement($ship_placement);
                        $location->setShot(false);
                        $this->em->persist($location);
                        $this->em->flush();
                    }
                }
            }
        }
    }

    /**
     * @param Grid $grid
     * @param Ship $ship
     * @return array|null
     */
    private function findFreeLocations(Grid $grid, Ship $ship){

        $freeLocations = null;

        // generate random position
        $x = rand(1, 8);
        $y = rand(1, 8);

        $freeLocations = $this->getFreeLocationsByPosition($grid, $ship->getHoles(), $x, $y, null);

        // check if locations for all holes were found // && count($freeLocations) == $ship->getHoles()
        if(is_array($freeLocations) && count($freeLocations) == $ship->getHoles()){

            return $freeLocations;

        } else {
            // search again for free locations
            return $this->findFreeLocations($grid, $ship);
        }
    }


    /**
     * @param Grid $grid
     * @param int $holes
     * @param int $x
     * @param int $y
     * @param string|null $axis
     * @return array|null
     */
    private function getFreeLocationsByPosition(Grid $grid, int $holes, int $x, int $y, string $axis = null)
    {
        $cycle = 2;
        $arr_axis = ['x', 'y'];

        if(is_null($axis) ||  ($axis !== 'x' && $axis !== 'y')){
            $cycle = 1;
            $value = rand(1,2);
            $axis = $arr_axis[$value-1];
        }

        if($axis == 'x'){

            $freeLocations = $this->getHorizontalFreeLocations($grid, $holes,  $x,  $y, null);

            // check if locations for all holes were found
            if(is_array($freeLocations) && count($freeLocations) == $holes)
            {
                return $freeLocations;

            } else if($cycle == 1){
                // try getting locations on the vertical axis
               return $this->getFreeLocationsByPosition($grid, $holes, $x, $y, 'y');
            } else {
                // no locations could be found for the given position
                return null;
            }
        }

        if($axis == 'y'){

            $freeLocations = $this->getVerticalFreeLocations($grid, $holes, $x, $y, null);

            // check if locations for all holes were found
            if(is_array($freeLocations) && count($freeLocations) == $holes)
            {
                return $freeLocations;

            } else if($cycle == 1){
                // try getting locations on the horizontal axis
              return  $this->getFreeLocationsByPosition($grid, $holes, $x, $y, 'x');
            }
            else {
                // no locations could be found for the given position
                return null;
            }
        }
    }

    /**
     * @param Grid $grid
     * @param int $holes
     * @param int $x
     * @param int $y
     * @param int|null $direction
     * @return array|null
     */
    private function getHorizontalFreeLocations(Grid $grid, int $holes, int $x, int $y, int $direction = null)
    {
        $cycle = 2;

        if(is_null($direction) || ($direction !== -1 && $direction !== 1)){
            $cycle = 1;
            $directions = [-1, 1];
            $value = array_rand([-1, 1],1);
            $direction = $directions[$value];
        }

        if($direction == -1){
            // search for free locations on the left direction
            $freeLocations = $this->getHorizontalFreeLocationsByDirection($grid, $holes, $x, $y, -1);

            // check if locations for all holes were  found on the left direction
            if(is_array($freeLocations) && count($freeLocations) == $holes)
            {
                return $freeLocations;

            } else if($cycle == 1){
                // try getting locations on the horizontal axis on the right direction
                return  $this->getHorizontalFreeLocations($grid, $holes, $x, $y, 1);
            } else {
                // no locations could be found on the horizontal axis
                return null;
            }
        }

        if($direction == 1){
            // search for free locations on the right direction
            $freeLocations = $this->getHorizontalFreeLocationsByDirection($grid, $holes, $x, $y, 1);

            // check if locations for all holes were  found on the left direction
            if(is_array($freeLocations) && count($freeLocations) == $holes)
            {
                return $freeLocations;

            } else if($cycle == 1){
                // try getting locations on the horizontal axis on the left direction
                return  $this->getHorizontalFreeLocations($grid, $holes, $x, $y, -1);
            } else {
                // no locations could be found on the horizontal axis
                return null;
            }
        }
    }

    /**
     * @param Grid $grid
     * @param int $holes
     * @param int $x
     * @param int $y
     * @param int|null $direction
     * @return array|null
     */
    private function getVerticalFreeLocations(Grid $grid, int $holes, int $x, int $y, int $direction = null)
    {
        $cycle = 2;

        if(is_null($direction) || ($direction !== -1 && $direction !== 1)){
            $cycle = 1;
            $directions = [-1, 1];
            $value = array_rand([-1, 1],1);
            $direction = $directions[$value];
        }

        if($direction == -1){
            // search for free locations above the given position
            $freeLocations = $this->getVerticalFreeLocationsByDirection($grid, $holes, $x, $y, -1);

            // check if locations for all holes were found above
            if(is_array($freeLocations) && count($freeLocations) == $holes)
            {
                return $freeLocations;

            } else if($cycle == 1){
                // try getting locations on the vertical axis beneath the given position
                return  $this->getVerticalFreeLocations($grid, $holes, $x, $y, 1);
            } else {
                // no locations could be found on the vertical axis
                return null;
            }
        }

        if($direction == 1){
            // search for free locations on the right direction
            $freeLocations = $this->getVerticalFreeLocationsByDirection($grid, $holes, $x, $y, 1);

            // check if locations for all holes were  found on the left direction
            if(is_array($freeLocations) && count($freeLocations) == $holes)
            {
                return $freeLocations;

            } else if($cycle == 1){
                // try getting locations on the horizontal axis on the left direction
                return  $this->getVerticalFreeLocations($grid, $holes, $x, $y, -1);
            } else {
                // no locations could be found on the horizontal axis
                return null;
            }
        }

    }

    /**
     * @param Grid $grid
     * @param int $holes
     * @param int $x
     * @param int $y
     * @param int $direction
     * @return array
     */
    private function getHorizontalFreeLocationsByDirection(Grid $grid, int $holes, int $x, int $y, int $direction)
    {
        $freeLocations = [];
        $locations = null;
        $location = null;
        $xStart = null;
        $xEnd = null;
        $values = [];

        if($direction == -1) {
            // get locations on the left direction
            $xStart = $x - $holes + 1 ;
            if ($xStart >= 1) {
                for ($i = $xStart; $i <= $x; $i++) {
                    $values[] = $i;
                }
            }
        } else if($direction == 1) {
            // get locations on the right direction
            $xEnd = $x + $holes -1;
            if ($xEnd <= 8) {
                for ($i = $x; $i <= $xEnd; $i++) {
                    $values[] = $i;
                }
            }
        }

        if(!empty($values)){
            $locations = $this->em
                ->getRepository(Location::class)
                ->findHorizontallyByPosition($grid,$values, $x, $y);

            // if there were not any locations found , than  new location can be created
            if(is_null($locations) || empty($locations)){
                foreach ($values as $value){
                    $location = new Location();
                    $location->setX($value);
                    $location->setY($y);
                    $location->setGrid($grid);

                    $freeLocations[] = $location;
                }
            }
        }
        return $freeLocations;
    }

    /**
     * @param Grid $grid
     * @param int $holes
     * @param int $x
     * @param int $y
     * @param int $direction
     * @return array
     */
    private function getVerticalFreeLocationsByDirection(Grid $grid, int $holes, int $x, int $y, int $direction)
    {
        $freeLocations = [];
        $locations = null;
        $location = null;
        $yStart = null;
        $yEnd = null;
        $values = [];

        if($direction == -1) {
            // get locations above
            $yStart = $y - $holes +1;
            if ($yStart >= 1) {
                for ($i = $yStart; $i <= $y; $i++) {
                    $values[] = $i;
                }
            }
        } else if($direction == 1) {
            // get locations beneath
            $yEnd = $y + $holes -1;
            if ($yEnd <= 8) {
                for ($i = $y; $i <= $yEnd; $i++) {
                    $values[] = $i;
                }
            }
        }

        if(!empty($values)){
            $locations = $this->em
                ->getRepository(Location::class)
                ->findVerticallyByPosition($grid,$values, $x, $y);

            // if there were not any locations found , than  new locations can be created
            if(is_null($locations) || empty($locations)){
                foreach ($values as $value){
                    $location = new Location();
                    $location->setX($x);
                    $location->setY($value);
                    $location->setGrid($grid);

                    $freeLocations[] = $location;
                }
            }
        }
        return $freeLocations;
    }
}