<?php
/**
 * Created by PhpStorm.
 * User: ioana.poetzschke
 * Date: 11.05.2020
 * Time: 10:24
 */

namespace App\Controller;

use App\Entity\Grid;
use App\Entity\Location;
use App\Entity\Ship;
use App\Entity\ShipPlacement;
use App\Service\GridService;
use App\Service\HelperService;
use App\Service\LocationService;
use Doctrine\ORM\EntityManager;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation\Request;

class PlayController extends  AbstractController
{

    /**
    * @Route("/start", name="start")
    */
    public function start(GridService $gridService)
    {
        $entityManager = $this->getDoctrine()->getManager();

        // delete all locations and ship_placements
        // delete all ship placements
        $entityManager->getRepository(Location::class)
            ->deleteAllLocations();
        // delete all ship placements
        $entityManager->getRepository(ShipPlacement::class)
            ->deleteAllShipPlacements();

        $entityManager->flush();

        // initialise own grid and create locations for all ships
        $ownGrid = $gridService->initialiseOwnGrid();

        $partyGrid = $gridService->initialisePartyGrid('party_grid');

        return new JsonResponse($partyGrid->getClientId());
    }

    /**
     * @Route("/play", name="play")
     */
    public function play(Request $request, GridService $gridService, LocationService $locationService)
    {
      /*  $request = new Request(array(
            'client_id'     => 'party_grid',
            'shot'  => 'A-6',
            'result' => 'miss',
            'message' => 'Your try'
        ));*/

      $em = $this->getDoctrine()->getManager();
      $positionArray = [];
      $nextPosition = null;
      $responseArray = [];
      $result = '';
      $targetLocation = null;

      $content = $request->request->all();

      if(isset($content['result'])){
          $result = $content['result'];
      }

      if(isset($content['shot'])){
          $positionArray = HelperService::convertStringToPositionArray($content['shot']);
      }

      // check request location
      $ownGrid = $gridService->getOwnGrid();
      if($ownGrid->getTotalHits() < $gridService::$MAX_TOTAL_SHOTS){
          // continue playing
          // check request location
         if( !empty($positionArray)){
             $ship = null;
             // continue playing
             $location = $locationService->getLocationByPosition($ownGrid, $positionArray['x'], $positionArray['y']);
             if($location instanceof  Location){
                 if($location->getShot() === false){
                     $location->setShot(true);
                     $em->persist($location);
                     if(!is_null($location->getShipPlacement())){
                         // ship has been shot
                         $ship_placement = $location->getShipPlacement();
                         $hits = $ship_placement->getHits() + 1;
                       //  $responseArray['hits'] = $hits;
                         // count hits of ship
                         $ship_placement->setHits($hits);
                         $em->persist($ship_placement);
                         $ownGrid->setTotalHits($ownGrid->getTotalHits() + 1);
                         $em->persist($ownGrid);
                         // save changes into DB
                         $em->flush();

                         $ship = $location->getShipPlacement()->getShip();
                         $responseArray['result'] = 'HIT ' . $ship->getName();

                         // check if ship sunk
                         if($ship->getHoles() == $hits){
                             $responseArray['message'] = $ship->getName() . ' SUNK';

                             if($ownGrid->getTotalHits() == $gridService::$MAX_TOTAL_SHOTS){
                                 // game is finished
                                 $responseArray['message'] = $responseArray['message'] . ' You won!';
                             }
                         }
                     }
                 } else {
                     $responseArray['message'] = 'You have already shot this location!';
                     if(!is_null($location->getShipPlacement())){
                         $responseArray['result'] = 'HIT ' . $location->getShipPlacement()->getShip()->getName();
                     } else {
                         $responseArray['result'] = 'MISS';
                     }
                 }

             } else {
                 $responseArray['result'] = 'MISS';
             }
         } else {
             $responseArray['message'] = 'An error occurred while finding location';
         }
      } else {
          $responseArray['message'] = 'You won!';
      }

      // generate a target location
      $positionArray = [];
      $foundPosition = null;
      $partyGrid = $gridService->getPartyGrid();
      if($partyGrid->getTotalHits() < $gridService::$MAX_TOTAL_SHOTS){
          // check result of a previous request
          if(isset($result) && strlen($result) > 0){
              $parsedResult = HelperService::parseResult($result);
              $responseArray['parsedResult'] = $parsedResult;
              if(!empty($parsedResult)){
                  if($parsedResult['hit'] === true &&
                      is_array($parsedResult['position']) &&
                      isset($parsedResult['position']['x']) &&
                      isset($parsedResult['position']['y']) &&
                      isset($parsedResult['ship_name'])
                  )
                  {
                      // get ship by name
                      $ship = $em->getRepository(Ship::class)
                          ->findOneBy(['name' => $parsedResult['ship_name']]);
                      $parsedResult['ship'] = $ship;

                      $responseArray['parsedResultship'] = $ship->getName();

                      if(isset($parsedResult['ship']) && $parsedResult['ship'] instanceof  Ship){
                          // update location : set ship placement
                          $location = $locationService->getLocationByPosition($partyGrid, $parsedResult['position']['x'], $parsedResult['position']['y']);
                          if($location instanceof  Location){
                              // check  if ship has been already shot
                              if(!is_null($location->getShipPlacement())){
                                  $ship_placement = $location->getShipPlacement();
                                  $ship_placement->setHits($ship_placement->getHits() + 1 );
                              } else {
                                  $ship_placement = $this->getDoctrine()->getRepository(ShipPlacement::class)
                                      ->findOneBy(['ship_id' => $ship->getId(), 'grid_id' => $partyGrid->getId()]);
                                  if($ship_placement instanceof  ShipPlacement){
                                      $ship_placement->setHits($ship_placement->getHits() + 1 );
                                  } else {
                                      $ship_placement = new ShipPlacement();
                                      $ship_placement->setShip($ship);
                                      $ship_placement->setGrid($partyGrid);
                                      $ship_placement->setHits(1);
                                  }
                              }
                              $location->setShipPlacement($ship_placement);
                              $location->setShot(true); // it is actually already set to true
                              $em->persist($location);
                              $em->flush();

                              $partyGrid->setTotalHits($partyGrid->getTotalHits() + 1);
                              $em->persist($partyGrid);
                              $em->flush();

                              // check if ship is not sunk
                              if($location->getShipPlacement()->getHits() < $location->getShipPlacement()->getShip()->getHoles()){
                                  // random nearby position
                                  $positionsArray = $locationService->getNearLocation($partyGrid, $location);
                                  if(!empty($positionsArray)){
                                      $foundPosition = $positionsArray[0];
                                  }
                              }
                          }
                      }
                  }
              }
          }

          if(!isset($foundPosition)){
              //check if a location exists that was shot and has a ship that was not sunk
              $nearLocation = null;
              $nearLocations = $this->getDoctrine()->getRepository(Location::class)
                                                    ->findShotLocationWithShipNotSunk($partyGrid);
              $responseArray['locations'] = $nearLocations;
              if(is_array($nearLocations) && count($nearLocations) > 0){
                  $responseArray['nearLocation'] = $nearLocations[0]['y'];
                  if(isset($nearLocations[0]['x']) && isset($nearLocations[0]['y'])){
                      $nearLocation = $locationService->getLocationByPosition($partyGrid, $nearLocations[0]['x'], $nearLocations[0]['y']);
                      $positionsArray = $locationService->getNearLocation($partyGrid, $nearLocation);
                      $responseArray['positions'] = $positionsArray;
                      if(!empty($positionsArray)){
                          $foundPosition = $positionsArray[0];
                      }
                  }
              }
              if(!is_null($foundPosition) && !empty($foundPosition) && isset($foundPosition['x']) && isset($foundPosition['y']))
              {
                  $positionArray = $foundPosition;
              } else {
                  // there is no ship that was hit and not sunk
                  // generate a random position that was not shot
                  // generate Location for the position
                  // set shot of Location to true
                  do{
                      $positionArray = HelperService::generateRandomPosition();
                      $existLocation = $this->getDoctrine()->getRepository(Location::class)
                          ->findOneBy(['grid_id' => $partyGrid->getId(), 'x' => $positionArray['x'], 'y' => $positionArray['y']]);
                      if($existLocation instanceof  Location){
                          $positionArray = HelperService::generateRandomPosition();
                      }
                  } while(!is_null($existLocation));
              }
          } else {
              $positionArray = $foundPosition;
          }

          $targetLocation = new Location();
          $targetLocation->setShipPlacement(null);
          $targetLocation->setX($positionArray['x']);
          $targetLocation->setY($positionArray['y']);
          $targetLocation->setGrid($partyGrid);
          $targetLocation->setShot(true);

          $em->persist($targetLocation);
          $em->flush();
      } else {
          $responseArray['message'] = 'You lost!';
      }
      $responseArray['shot'] =  $targetLocation instanceof Location ? HelperService::convertPositionArrayToString([$targetLocation->getX(), $targetLocation->getY()]): '';

      return new JsonResponse($responseArray);

    }
}