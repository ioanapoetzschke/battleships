<?php
/**
 * Created by PhpStorm.
 * User: ioana.poetzschke
 * Date: 16.05.2020
 * Time: 10:26
 */

namespace App\Entity;

class Position {

    public $x;

    public $y;

    /**
     * @return int
     */
    public function getX()
    {
        return (int)$this->x;
    }

    /**
     * @param int $x
     */
    public function setX($x): void
    {
        $this->x = $x;
    }

    /**
     * @return int
     */
    public function getY()
    {
        return (int)$this->y;
    }

    /**
     * @param int $y
     */
    public function setY($y): void
    {
        $this->y = $y;
    }
}