<?php

namespace App\Entity;

use App\Repository\LocationRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass=LocationRepository::class)
 */
class Location
{
    /**
     * @ORM\Id()
     * @ORM\GeneratedValue()
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="integer")
     */
    private $grid_id;

    /**
     * @ORM\Column(type="integer", nullable=true)
     */
    private $ship_placement_id;

    /**
     * @ORM\Column(type="integer")
     */
    private $x;

    /**
     * @ORM\Column(type="integer")
     */
    private $y;

    /**
     * @ORM\Column(type="boolean")
     */
    private $shot;

    /**
     * @ORM\ManyToOne(targetEntity=ShipPlacement::class, inversedBy="locations", cascade={"persist"})
     */
    private $ship_placement;

    /**
     * @ORM\ManyToOne(targetEntity=Grid::class, inversedBy="locations")
     * @ORM\JoinColumn(nullable=false)
     */
    private $grid;

    public function __construct()
    {
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getGridId(): ?int
    {
        return $this->grid_id;
    }

    public function setGridId(int $grid_id): self
    {
        $this->grid_id = $grid_id;

        return $this;
    }

    public function getShipPlacementId(): ?int
    {
        return $this->ship_placement_id;
    }

    public function setShipPlacementId(?int $ship_placement_id): self
    {
        $this->ship_placement_id = $ship_placement_id;

        return $this;
    }

    public function getX(): ?int
    {
        return $this->x;
    }

    public function setX(int $x): self
    {
        $this->x = $x;

        return $this;
    }

    public function getY(): ?int
    {
        return $this->y;
    }

    public function setY(int $y): self
    {
        $this->y = $y;

        return $this;
    }

    public function getShot(): ?bool
    {
        return $this->shot;
    }

    public function setShot(bool $shot): self
    {
        $this->shot = $shot;

        return $this;
    }

    public function getShipPlacement(): ?ShipPlacement
    {
        return $this->ship_placement;
    }

    public function setShipPlacement(?ShipPlacement $ship_placement): self
    {
        $this->ship_placement = $ship_placement;

        return $this;
    }

    public function getGrid(): ?Grid
    {
        return $this->grid;
    }

    public function setGrid(?Grid $grid): self
    {
        $this->grid = $grid;

        return $this;
    }
}
