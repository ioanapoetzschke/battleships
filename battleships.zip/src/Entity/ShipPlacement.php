<?php

namespace App\Entity;

use App\Repository\ShipPlacementRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass=ShipPlacementRepository::class)
 */
class ShipPlacement
{
    /**
     * @ORM\Id()
     * @ORM\GeneratedValue()
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="integer")
     */
    private $hits;

    /**
     * @ORM\Column(type="integer")
     */
    private $ship_id;

    /**
     * @ORM\Column(type="integer")
     */
    private $grid_id;

    /**
     * @ORM\OneToMany(targetEntity=Location::class, mappedBy="ship_placement")
     */
    private $locations;

    /**
     * @ORM\ManyToOne(targetEntity=Ship::class, cascade={"persist", "remove"})
     * @ORM\JoinColumn(nullable=false)
     */
    private $ship;

    /**
     * @ORM\ManyToOne(targetEntity=Grid::class, inversedBy="shipPlacements")
     * @ORM\JoinColumn(nullable=false)
     */
    private $grid;

    public function __construct()
    {
        $this->locations = new ArrayCollection();
    }


    public function getId(): ?int
    {
        return $this->id;
    }

    public function getHits(): ?int
    {
        return $this->hits;
    }

    public function setHits(int $hits): self
    {
        $this->hits = $hits;

        return $this;
    }

    public function getShipId(): ?int
    {
        return $this->ship_id;
    }

    public function setShipId(int $ship_id): self
    {
        $this->ship_id = $ship_id;

        return $this;
    }

    public function getGridId(): ?int
    {
        return $this->grid_id;
    }

    public function setGridId(int $grid_id): self
    {
        $this->grid_id = $grid_id;

        return $this;
    }

    /**
     * @return Collection|Location[]
     */
    public function getLocations(): Collection
    {
        return $this->locations;
    }

    public function addLocation(Location $location): self
    {
        if (!$this->locations->contains($location)) {
            $this->locations[] = $location;
            $location->setShipPlacement($this);
        }

        return $this;
    }

    public function removeLocation(Location $location): self
    {
        if ($this->locations->contains($location)) {
            $this->locations->removeElement($location);
            // set the owning side to null (unless already changed)
            if ($location->getShipPlacement() === $this) {
                $location->setShipPlacement(null);
            }
        }

        return $this;
    }

    public function getShip(): ?Ship
    {
        return $this->ship;
    }

    public function setShip(Ship $ship): self
    {
        $this->ship = $ship;

        return $this;
    }

    public function getGrid(): ?Grid
    {
        return $this->grid;
    }

    public function setGrid(?Grid $grid): self
    {
        $this->grid = $grid;

        return $this;
    }
}
