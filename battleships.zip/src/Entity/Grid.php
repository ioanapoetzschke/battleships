<?php

namespace App\Entity;

use App\Repository\GridRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass=GridRepository::class)
 */
class Grid
{
    /**
     * @ORM\Id()
     * @ORM\GeneratedValue()
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="string", length=30)
     */
    private $client_id;

    /**
     * @ORM\Column(type="integer")
     */
    private $total_hits;

    /**
     * @ORM\OneToMany(targetEntity=Location::class, mappedBy="grid", orphanRemoval=true)
     */
    private $locations;

    /**
     * @ORM\OneToMany(targetEntity=ShipPlacement::class, mappedBy="grid")
     */
    private $shipPlacements;

    public function __construct()
    {
        $this->locations = new ArrayCollection();
        $this->shipPlacements = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getClientId(): ?string
    {
        return $this->client_id;
    }

    public function setClientId(string $client_id): self
    {
        $this->client_id = $client_id;

        return $this;
    }

    public function getTotalHits(): ?int
    {
        return $this->total_hits;
    }

    public function setTotalHits(int $total_hits): self
    {
        $this->total_hits = $total_hits;

        return $this;
    }

    /**
     * @return Collection|Location[]
     */
    public function getLocations(): Collection
    {
        return $this->locations;
    }

    public function addLocation(Location $location): self
    {
        if (!$this->locations->contains($location)) {
            $this->locations[] = $location;
            $location->setGrid($this);
        }

        return $this;
    }

    public function removeLocation(Location $location): self
    {
        if ($this->locations->contains($location)) {
            $this->locations->removeElement($location);
            // set the owning side to null (unless already changed)
            if ($location->getGrid() === $this) {
                $location->setGrid(null);
            }
        }

        return $this;
    }

    /**
     * @return Collection|ShipPlacement[]
     */
    public function getShipPlacements(): Collection
    {
        return $this->shipPlacements;
    }

    public function addShipPlacement(ShipPlacement $shipPlacement): self
    {
        if (!$this->shipPlacements->contains($shipPlacement)) {
            $this->shipPlacements[] = $shipPlacement;
            $shipPlacement->setGrid($this);
        }

        return $this;
    }

    public function removeShipPlacement(ShipPlacement $shipPlacement): self
    {
        if ($this->shipPlacements->contains($shipPlacement)) {
            $this->shipPlacements->removeElement($shipPlacement);
            // set the owning side to null (unless already changed)
            if ($shipPlacement->getGrid() === $this) {
                $shipPlacement->setGrid(null);
            }
        }

        return $this;
    }
}
